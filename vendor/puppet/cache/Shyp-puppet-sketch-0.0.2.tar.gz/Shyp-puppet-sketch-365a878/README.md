# Sketch Puppet Module for Boxen

Install [Sketch](http://bohemiancoding.com/sketch/), a design app for Mac.

## Usage

```puppet
include sketch
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
